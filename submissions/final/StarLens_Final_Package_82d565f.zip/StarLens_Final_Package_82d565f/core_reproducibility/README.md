# DopaTeam reproducibility package

This package preserves DopaTeam version 0.4.0 at [commit 34c4d158](https://github.com/Rifelimo/DopaTeam/tree/34c4d158ff1ba4be7611ea2d6a35b1c6f3bb394f). It contains the original 44 tracked source files, a serialized synthetic input, command line results, and a JSON file downloaded through the prototype's **Export evidence** button.

The example is a deterministic conditional simulation. It is not a reproduction of the research article or evidence of clinical validity, cell identity, treatment efficacy, or a biological transition clock.

## Contents

| Path | Purpose |
| --- | --- |
| `PINNED_VERSION.json` | Exact commit and SHA-256 hashes of the 44 source files |
| `code/` | Unmodified source snapshot, including the dependency lockfile and tests |
| `inputs/synthetic_input.json` | Serialized synthetic fixture: 82 aligned regions, one profile, 30 reference maps |
| `outputs/comparison.json` | CLI comparison of that input, including the five strongest associations and leave-one-out ranges |
| `outputs/state_model.json` | JavaScript model example with default parameters |
| `outputs/python_reference.json` | Independent Python conditional model example |
| `outputs/interface_export.json` | Actual downloaded interface export, with 30 association summaries and model results |
| `verification/ui_export_checks.json` | Browser capture audit, including the import and download checks |
| `verification/deployment.json` | Recorded deployment identity and pinned commit |
| `verification/run/` | Saved reproduction summary and execution logs |
| `reproduce.py` | Reproduction and comparison runner |
| `tools/capture_ui_export.mjs` | Optional script to repeat the browser import and export |
| `MANIFEST.sha256` | Integrity hashes for every packaged file except the manifest itself |

The recorded run passed **26 JavaScript tests and 16 Python tests**, all output comparisons, and a clean production build. Full command output, exit codes and runtime versions are in `verification/run/`. The separate browser capture passed all nine recorded checks.

The recorded interface export was captured on September 14, 2026 from `https://dopateam.vercel.app/prototype.html`. The browser audit records a parameter reset, import of the packaged input, visible correlation `0.818`, and the downloaded filename `dopateam_evidence.json`. It records no browser page errors or failed asset responses. The live URL may change after this capture; the source snapshot and archived files preserve this version.

## Reproduce the calculations and checks

Requirements: Node.js **22.12.0 or newer**, npm, and Python **3.10 or newer**. The full build needs access to the npm registry or a populated npm cache. Python uses its standard library.

Open a terminal in this package directory and run:

```sh
python3 reproduce.py
```

The runner uses a temporary copy of `code/`. It verifies source checksums, regenerates the synthetic input and CLI outputs, runs the 26 JavaScript and 16 Python tests, installs locked dependencies with `npm ci`, and builds the interface. It compares regenerated results with the archived outputs and the actual interface export. A successful invocation exits with status 0; inspect the saved summary and logs for the result of that invocation.

New results go into `reproduced/`: `summary.json`, `logs/*.stdout.txt`, `logs/*.stderr.txt`, and `outputs/{synthetic_input,comparison,state_model,python_reference,all_associations}.json`. The original source, input and captured export remain unchanged.

Choose a different output directory or omit dependency installation and the interface build:

```sh
python3 reproduce.py --output /absolute/path/to/results
python3 reproduce.py --skip-build --output reproduced-no-build
```

Each run needs a new or empty output directory. `--skip-build` retains numerical regeneration, comparisons and tests. It does not establish that the interface builds in that environment. Saved results under `verification/run/` document the recorded package run; they do not substitute for rerunning it on another machine.

The three underlying calculation commands, run from `code/`, are:

```sh
node scripts/compare_bundle.mjs --input ../inputs/synthetic_input.json
node scripts/state_demo.mjs
python3 scripts/reference.py --pretty
```

The first command reads the saved input. `state_demo.mjs` uses its built-in default synthetic fixture and does not accept an input-file argument. `reference.py` uses a different regional fixture, so its molecular descriptor correlations must not be equated with the 30-map JavaScript ranking. Its equivalent scalar model results can be compared after mapping the parameter names.

## Expected results

| Quantity | Default result |
| --- | --- |
| Strongest reference | `reference-17`, Spearman rho `0.81830846420914` |
| Remaining top-five order | `reference-5`, `reference-20`, `reference-13`, `reference-19` |
| State A output and label | `1.008`, `Compensation compatible` |
| State B output and label | `0.576`, `Dysfunction compatible` |
| Functional gap | Approximately `0.432` |
| Structural gap | `0` |
| Functional separation divided by stipulated noise | `4.32` |
| Transition times A and B | Approximately `2.3111172096338657` and `0`, in arbitrary model time |

Rankings use descending absolute Spearman correlation while retaining the sign. The top-five CLI associations match the first five interface associations; the full regenerated ranking matches all 30 interface associations. Model parameters and state results agree between the JavaScript example and the default interface export. The runner compares identifiers, text, booleans and ordering exactly, and finite numerical values with an absolute tolerance of `1e-12`. Formatting and the interface's `exportedAt` timestamp are not numerical reproduction criteria.

The interface export deliberately omits raw input arrays. Keep `inputs/synthetic_input.json` with it to reproduce the correlations. CLI leave-one-out ranges and model transition times are additional outputs absent from the interface export.

## Optional fresh interface export

A new browser capture requires Playwright with Chromium installed. This is separate from `reproduce.py`; a successful numerical run alone does not prove that a fresh browser download occurred.

Start the interface from a disposable copy of the source:

```sh
dopateam_ui_dir=$(mktemp -d)
cp -R code "$dopateam_ui_dir/code"
cd "$dopateam_ui_dir/code"
npm ci
npm run dev
```

In another terminal, from this package directory, run:

```sh
PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs node tools/capture_ui_export.mjs
```

Omit `PLAYWRIGHT_MODULE` if `playwright` is already resolvable by Node. The default target is `http://127.0.0.1:5184/prototype.html`; `PROTOTYPE_URL` can select another running instance. The script resets model parameters, imports the packaged input, and clicks **Export evidence**. New files default to `reproduced/captured_interface_export.json` and `reproduced/ui_export_checks.json`. `UI_EXPORT_PATH` and `UI_AUDIT_PATH` override those destinations.

Both destination files must be new. The capture script refuses to overwrite earlier evidence. If you capture before running `reproduce.py`, choose a separate output directory for the numerical run.

## Verify package integrity

From the extracted package directory, verify every archived file on macOS:

```sh
shasum -a 256 -c MANIFEST.sha256
```

On Linux, use `sha256sum -c MANIFEST.sha256`. The manifest detects changed or missing payload files. The runner separately checks the complete source inventory against `PINNED_VERSION.json`.

## Interpretation limits

The structural vector and reference maps are identical between the two constructed states by assumption. Functional output follows the toy equation `F = S × C`; thresholds, noise and decay rates are stipulated. `S` is a latent model quantity, not MRI volume or a neuron count. The independent scalar functional measurement separates this constructed pair only. Molecular correlations are descriptive; leave-one-out ranges are sensitivity summaries, not confidence intervals, and there is no spatial null inference.

This package contains no video and performs no external submission or publication.

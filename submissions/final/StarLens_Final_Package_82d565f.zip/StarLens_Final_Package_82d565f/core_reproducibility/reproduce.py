#!/usr/bin/env python3
"""Reproduce the pinned DopaTeam computations without changing code/ or evidence."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
TOLERANCE = 1e-12


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def equal(actual, expected, path="value"):
    """Compare JSON structure exactly and finite numeric values with a small tolerance."""
    if isinstance(expected, bool) or expected is None:
        if actual is not expected:
            raise ValueError(f"{path}: boolean/null mismatch")
    elif isinstance(expected, (int, float)):
        if isinstance(actual, bool) or not isinstance(actual, (int, float)) or not math.isfinite(actual) or not math.isfinite(expected) or not math.isclose(actual, expected, rel_tol=0, abs_tol=TOLERANCE):
            raise ValueError(f"{path}: numeric mismatch: {actual!r} != {expected!r}")
    elif isinstance(expected, dict):
        if not isinstance(actual, dict) or actual.keys() != expected.keys():
            raise ValueError(f"{path}: object keys differ")
        for key in expected:
            equal(actual[key], expected[key], f"{path}.{key}")
    elif isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            raise ValueError(f"{path}: list lengths differ")
        for index, value in enumerate(expected):
            equal(actual[index], value, f"{path}[{index}]")
    elif type(actual) is not type(expected) or actual != expected:
        raise ValueError(f"{path}: value mismatch")


def verify_source(pin):
    expected = {row["path"]: row["sha256"] for row in pin["code_files"]}
    files = {p.relative_to(ROOT / "code").as_posix(): p for p in (ROOT / "code").rglob("*") if p.is_file()}
    # Finder can add these after extraction; they are not source or executable input.
    files = {name: path for name, path in files.items() if path.name != ".DS_Store"}
    if files.keys() != expected.keys() or len(files) != pin["code_file_count"]:
        raise ValueError("code/ file inventory differs from the pinned snapshot. Extract a clean copy of the ZIP.")
    for name, path in files.items():
        if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != expected[name]:
            raise ValueError(f"Pinned source checksum mismatch: {name}")
    return files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "reproduced", help="Fresh output directory (default: reproduced/ beside this script).")
    parser.add_argument("--skip-build", action="store_true", help="Run calculations and tests without installing or building the UI; build is recorded as skipped.")
    args = parser.parse_args()
    out = args.output.expanduser().resolve()
    if out == ROOT or ROOT.is_relative_to(out) or any(out.is_relative_to(ROOT / p) for p in ["code", "inputs", "outputs", "verification", "tools"]):
        parser.error("Choose a fresh directory outside the archived source and evidence folders.")
    if out.exists() and any(out.iterdir()):
        parser.error("Output directory is not empty. Choose a new --output path to preserve previous evidence.")
    out.mkdir(parents=True, exist_ok=True)
    (out / "logs").mkdir(exist_ok=True)
    (out / "outputs").mkdir(exist_ok=True)
    summary = {"status": "running", "started_at_utc": datetime.now(timezone.utc).isoformat(), "numeric_absolute_tolerance": TOLERANCE, "checks": [], "commands": [], "build": "skipped" if args.skip_build else "pending"}
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["NO_COLOR"] = "1"
    env["npm_config_update_notifier"] = "false"

    def check(name, actual, expected):
        equal(actual, expected, name)
        summary["checks"].append(name)

    def run(label, command, cwd, json_name=None):
        print(f"Running {label}...", flush=True)
        result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace")
        for stream in ("stdout", "stderr"):
            (out / "logs" / f"{label}.{stream}.txt").write_text(getattr(result, stream), encoding="utf-8")
        summary["commands"].append({"name": label, "argv": command, "working_directory": "temporary source copy", "exit_code": result.returncode, "stdout": f"logs/{label}.stdout.txt", "stderr": f"logs/{label}.stderr.txt"})
        if result.returncode:
            raise RuntimeError(f"{label} failed with exit code {result.returncode}. See saved logs.")
        if json_name:
            parsed = json.loads(result.stdout)
            write_json(out / "outputs" / json_name, parsed)
            return parsed
        return result.stdout + result.stderr

    try:
        pin = read_json(ROOT / "PINNED_VERSION.json")
        summary["commit"] = pin["commit"]
        files = verify_source(pin)
        summary["checks"].append(f"All {len(files)} pinned source files match SHA-256")
        if sys.version_info < (3, 10):
            raise RuntimeError("Python 3.10 or newer is required.")
        with tempfile.TemporaryDirectory(prefix="dopateam-reproduce-") as tmp:
            work = Path(tmp)
            for name, source in files.items():
                destination = work / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
            shutil.copy2(ROOT / "inputs/synthetic_input.json", work / "synthetic_input.json")
            node = run("node_version", ["node", "--version"], work).strip()
            npm = run("npm_version", ["npm", "--version"], work).strip()
            python = run("python_version", ["python3", "--version"], work).strip()
            version = tuple(int(part) for part in node.lstrip("v").split(".")[:3])
            if version < (22, 12, 0):
                raise RuntimeError("Node.js 22.12.0 or newer is required by the pinned project.")
            summary["environment"] = {"os": platform.platform(), "node": node, "npm": npm, "python": python, "runner_python": platform.python_version()}
            js = "import {syntheticBundle} from './src/data/synthetic.mjs'; console.log(JSON.stringify(syntheticBundle));"
            regenerated_input = run("generate_input", ["node", "--input-type=module", "-e", js], work, "synthetic_input.json")
            supplied = read_json(ROOT / "inputs/synthetic_input.json")
            check("Supplied synthetic input matches the pinned generator", regenerated_input, supplied)
            comparison = run("compare", ["node", "scripts/compare_bundle.mjs", "--input", "synthetic_input.json", "--profile", "synthetic"], work, "comparison.json")
            state = run("state_model", ["node", "scripts/state_demo.mjs"], work, "state_model.json")
            reference = run("python_reference", ["python3", "scripts/reference.py", "--pretty"], work, "python_reference.json")
            for filename, result in [("comparison.json", comparison), ("state_model.json", state), ("python_reference.json", reference)]:
                check(f"Reproduced {filename} matches saved evidence", result, read_json(ROOT / "outputs" / filename))
            js = "import {readFileSync} from 'node:fs'; import {validateBundle} from './src/core/bundle.mjs'; import {rankMaps} from './src/core/molecular.mjs'; const b=validateBundle(JSON.parse(readFileSync('synthetic_input.json','utf8'))); const p=b.profiles.find(p=>p.id==='synthetic'); console.log(JSON.stringify(rankMaps(p.values,b.maps).map(({id,name,rho})=>({id,name,rho}))));"
            associations = run("all_associations", ["node", "--input-type=module", "-e", js], work, "all_associations.json")
            ui = read_json(ROOT / "outputs/interface_export.json")
            for key in ["project", "dataKind", "profile"]:
                check(f"UI and CLI {key} match", ui[key], comparison[key])
            check("UI version matches pinned package", ui["version"], pin["version"])
            check("UI source metadata matches imported input", ui["source"], supplied["source"])
            check("Region and map counts", [comparison["regionCount"], comparison["mapCount"], len(ui["associations"])], [82, 30, 30])
            check("All 30 UI associations match calculations from imported input", ui["associations"], associations)
            check("UI top five match CLI report", ui["associations"][:5], [{key: item[key] for key in ["id", "name", "rho"]} for item in comparison["topMaps"]])
            check("State demo strongest references match UI", state["strongestReferences"], [{key: item[key] for key in ["id", "rho"]} for item in ui["associations"][:5]])
            check("UI parameters match default state demo", ui["parameters"], state["parameters"])
            check("UI model result matches state demo", ui["result"], state["states"])
            check("UI does not include raw input arrays", [ui["rawImportedArraysIncluded"], any("values" in item for item in ui["associations"])], [False, False])
            timestamp = datetime.fromisoformat(ui["exportedAt"].replace("Z", "+00:00"))
            if timestamp.tzinfo is None:
                raise ValueError("UI export timestamp must include a timezone.")
            summary["checks"].append("UI export contains a valid timestamp (time is not a reproducible numeric result)")
            check("Python and JavaScript model outputs agree", [reference["states"]["A"]["F"], reference["states"]["B"]["F"], reference["assays"]["functional_output"]["delta_over_sigma"], reference["states"]["A"]["transition_time"], reference["states"]["B"]["transition_time"]], [state["states"]["a"]["output"], state["states"]["b"]["output"], state["states"]["normalizedSeparation"], state["transitionTime"]["a"], state["transitionTime"]["b"]])
            js_tests = run("javascript_tests", ["npm", "test"], work)
            py_tests = run("python_tests", ["npm", "run", "test:python"], work)
            js_count = re.search(r"(?:#|ℹ) tests (\d+)", js_tests)
            py_count = re.search(r"Ran (\d+) tests?", py_tests)
            if not js_count or not py_count:
                raise ValueError("Tests exited successfully but their counts could not be verified from the saved logs.")
            check("Expected JavaScript and Python test counts", [int(js_count[1]), int(py_count[1])], [26, 16])
            summary["test_counts"] = {"javascript": int(js_count[1]), "python": int(py_count[1]), "total": int(js_count[1]) + int(py_count[1])}
            if not args.skip_build:
                run("npm_ci", ["npm", "ci", "--include=dev"], work)
                run("build", ["npm", "run", "build"], work)
                if not (work / "prototype-dist/prototype.html").is_file() or not list((work / "prototype-dist/assets").glob("*.js")):
                    raise ValueError("Build exited successfully but expected prototype HTML/JS assets are missing.")
                summary["build"] = "passed"
                summary["checks"].append("Clean dependency installation and production prototype build passed")
        verify_source(pin)
        summary["checks"].append("Pinned code remained unchanged after reproduction")
        summary["status"] = "passed"
    except Exception as error:
        summary["status"] = "failed"
        summary["error"] = str(error)
        print(f"FAILED: {error}", file=sys.stderr)
    finally:
        summary["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        write_json(out / "summary.json", summary)
    print(f"{summary['status'].upper()}: {out / 'summary.json'}")
    return 0 if summary["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())

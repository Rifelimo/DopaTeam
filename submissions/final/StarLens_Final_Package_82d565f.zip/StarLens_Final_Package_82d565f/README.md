# StarLens final source and reproducibility package

Website: https://starlens-dopateam.vercel.app/

Source: https://github.com/Rifelimo/DopaTeam/tree/82d565fd689fd562450327d37c6a83f13692cd38

This package contains the original code for the current website. All 60 tracked files from the pinned commit are included without changes, together with synthetic inputs, actual browser exports, reproduction steps and verification logs. The 60 files include the earlier 48-hour submission ZIP.

A clean dependency installation and production build generated 15 files. Every file is identical, byte for byte, to the corresponding file on the public website. The appearance and calculations have been preserved.

## What changed since the 48-hour checkpoint

The final version adds the StarLens presentation, four-page build and a reported-study explorer. Users can switch study and comparison group, inspect values and missing entries, view selected regional effect sizes and export the evidence with its source. The original synthetic sandbox and model remain available as separate views.

The code was merged into main through pull request 1. This package records and verifies that version. It does not present the earlier research as a new experiment.

## Contents

| Location | Contents |
| --- | --- |
| `source/` | All 60 tracked files from commit `82d565fd689fd562450327d37c6a83f13692cd38`, including source, lockfile, tests, configuration, licenses and documentation. |
| `SOURCE_PIN.json` | Pinned commit and SHA256 for every source file. |
| `website/` | Preserved public build, identical to the build from this source. |
| `outputs/vercel_workspace_export.json` | Actual browser export from the synthetic workspace. |
| `outputs/reported_study_export.json` | Actual browser export of the selected reported study result. |
| `outputs/session_record.json` | Selected inputs, settings, outputs and scope. |
| `core_reproducibility/inputs/synthetic_input.json` | Complete 82-region synthetic input with 30 reference maps. |
| `verification/` | Current source test logs, build comparison, browser checks and offline output verification. |
| `docs/FINAL_SUMMARY.md` | Short explanation of what changed, results and unfinished work. |
| `docs/DEMO_STEPS.md` | Four minute presentation guide. |
| `core_reproducibility/` | Unchanged earlier package for tracing the original calculations and checkpoint. |
| `snapshot/`, `inputs/atlas_browser_export.json` | Optional external atlas build and its separate 68-region synthetic example. |

## Check the package and results

Use Node.js 22.12 or newer and Python 3.10 or newer. From this package directory, before adding dependencies inside it:

```sh
python3 verification/check_package.py
```

This verifies file hashes, the exact source inventory, all 30 synthetic associations and the default model against the captured export. It also checks the selected study export and all 59 selectable study, group and marker combinations. It does not rerun the original cohort research.

The older core checks and the optional atlas reference run separately. Their counts and scope are reported separately, not added to the current repository test count.

## Rebuild and run the original source

Make a working copy so that dependency and build files do not change the archived source inventory:

```sh
work_dir=$(mktemp -d)
cp -R source "$work_dir/source"
cd "$work_dir/source"
npm ci --ignore-scripts --no-audit --no-fund
npm test
npm run test:python
npm run build
npm run preview
```

Open http://127.0.0.1:5184/ for the website, or http://127.0.0.1:5184/prototype.html for the workspace. Stop the server with Control-C. Installing dependencies requires access to the npm registry. The source uses a pinned lockfile.

The recorded run used Node 23.10.0 and Python 3.14.3. All 31 JavaScript tests and 16 Python tests passed. The production build passed. See `verification/source_test_run.json` and its three full logs.

## Run the preserved build without npm

```sh
python3 verification/serve_snapshot.py --port 5992
```

Open http://127.0.0.1:5992/. The four workspace views are Study evidence, Regional sandbox, Competing states and Next experiment. Original external links and font requests remain unchanged.

## Results in plain English

- The synthetic sandbox compares 82 invented regional values with 30 invented reference maps. Its strongest correlation is **0.818308**, with reference 17. Every exported association matches the source calculation.
- The model holds the observations fixed and changes an assumed response gain. Its outputs are **1.008** and **0.576**. The difference is **0.432**. Dividing by assumed noise SD **0.1** gives **4.32**. These are simulated outputs, not measured treatment effects.
- The selected reported study result is SST in AD versus controls: rho **-0.639**, reported q **0.002**. Its exported object matches the source exactly. The panel includes eleven selected regional effect sizes; it is not a complete regional dataset or a new analysis.
- All **15 built website files** match the live website byte for byte. The browser check confirmed study display, sandbox results, parameter changes, Reset and the functional measurement example.

## Scope and remaining work

The main website has complete editable source and a verified build. The linked Neural Observatory is an optional separate application. Its public compiled snapshot and synthetic export are included, but its original editable source is not. It is not required to build or demonstrate the main site.

Research associations provide context. Synthetic results demonstrate calculations and assumptions. Neither establishes diagnosis, identifies an effective drug or demonstrates patient benefit. Independent biological experiments remain future work.

This archive was prepared locally for review. The pinned website source is already on GitHub. Publishing this additional archive is a separate action.

# Four minute demonstration

Use the final [StarLens site](https://starlens-dopateam.vercel.app), then its `/prototype.html` page. The sequence is reported study evidence, regional sandbox, competing states and next experiment. The external observatory is separate and optional. Check displayed settings before quoting default model outputs.

## 0:00 to 1:10 · Start with the reported research

Show the study evidence panel and distinguish the 2025 publication from the 2026 manuscript.

Say: “Our starting point is earlier research. The newer study analysed baseline data from 1,435 participants across 82 regions. It found spatial associations between brain tissue loss and biological reference maps, including serotonin receptors and gene signatures associated with inhibitory neurons. These are reported research results, not calculations performed by this demonstration.”

Show the 11 region Figure 2A excerpt.

Say: “This selected excerpt covers 11 of the study’s 82 regions. The reported left hippocampal effect size is minus 1.44. That is Cohen’s d, not a percentage of tissue lost. We have not converted these values into a complete 3D data map.”

## 1:10 to 1:50 · Make the switch to synthetic data explicit

Open the regional sandbox. Point to the synthetic label before interpreting its comparison or changing a selection.

Say: “We now switch from reported evidence to a synthetic example. This lets us explore regional comparisons without presenting invented values as participant measurements. A correlation describes the relationship between these example patterns. It is not diagnostic accuracy, a treatment effect or a reproduction of the manuscript.”

Record the selected inputs and displayed result together. Do not substitute a coefficient from the external cortical atlas or another preset.

## 1:50 to 3:05 · Compare the two constructed states

Open **3 · Competing states**. Confirm latent functional substrate **0.72**, response efficacy A **1.4**, response efficacy B **0.8**, and function threshold **0.8**. The noise standard deviation is **0.1** in the Next experiment view.

Show that the MRI or atlas observation gap is **0**, while the modelled outputs are **1.008** and **0.576**. Their difference is **0.432**. In Next experiment, the independent functional output shows a separation of **4.32**, this gap divided by the noise standard deviation.

Say: “The first observation cannot identify which of these two constructed states is present. Under the assumptions we put into this model, an independent functional output differs. The point is to ask which measurement could distinguish competing explanations. We have not shown that these states correspond to real SST cell states.”

If time permits, change one setting and explain the changed output. Restore the defaults before closing this section. Do not describe the separation value as a probability, significance test or validated threshold.

## 3:05 to 4:00 · Name the next measurement and the limit

Open **4 · Next experiment** and show the independent functional output.

Say: “A future study would need to establish which cells are SST cells and define what useful function means under matched stress. We could examine their inhibitory effect on identified target cells, with appropriate comparisons and viability measurements. A change in activity alone would not answer that question. Our contribution here is the demonstration and its explicit assumptions, not a completed biological experiment.”

Close: “We want to make the uncertainty useful: show what the first measurement cannot resolve, then identify the observation that could change our conclusion.”

## Readiness checklist, separate from the pitch

- Record the final site URL, selected inputs, state settings, displayed outputs and provenance together.
- Verify the captured browser export against the selected inputs or indices, settings and displayed outputs. Keep provenance with that record.
- Use the pinned original source at commit `82d565fd689fd562450327d37c6a83f13692cd38`. Its 31 JavaScript tests, 16 Python tests and build passed. All 15 built files match the public website.

## Optional external atlas, outside the four minutes

The observatory link opens a different site with 68 cortical parcels and 14 deep structures shown for anatomy only. Its reviewed synthetic coefficient is approximately **0.0284765431**. The earlier 82 region synthetic example has coefficient **0.8183084642**. Neither is a manuscript result or interchangeable with a currently selected sandbox output.

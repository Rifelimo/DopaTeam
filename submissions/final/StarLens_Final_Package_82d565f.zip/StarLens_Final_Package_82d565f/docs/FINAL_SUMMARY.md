# StarLens: from reported evidence to a testable question

We use [StarLens](https://starlens-dopateam.vercel.app) to connect earlier research with a synthetic demonstration: the same observation can be compatible with different underlying states. A second measurement may distinguish them under explicit assumptions.

## Reported research provides context

The study panel distinguishes the published 2025 research from the 2026 manuscript. The latter analysed baseline data from 1,435 ADNI participants across 82 regions. Its reported Alzheimer’s versus control correlations include 5-HT1A CUMI **−0.609**, WAY **−0.600**, SST **−0.639**, VIP **−0.478** and D2 **−0.438**. The reported SST q value is **0.002**.

The regional panel reproduces 11 reported Alzheimer’s effect sizes from Figure 2A, including left hippocampus **−1.44** and left amygdala **−1.38**. These are Cohen’s d values, not percentages of tissue lost. This excerpt covers 11 of 82 regions. It is neither a complete dataset nor a new computation, and is not mapped onto the separate 3D atlas.

## The sandbox is synthetic

The sandbox illustrates reasoning rather than validating the research. At the reviewed state defaults, latent functional substrate is **0.72**, response efficacies are **1.4** and **0.8**, and noise standard deviation is **0.1**. The observation gap is **0**, while modelled functional outputs are **1.008** and **0.576**. Their gap of **0.432**, divided by noise standard deviation, gives **4.32**, not a probability or clinical threshold.

The first observation cannot distinguish these constructed states. The additional output differs under specified measurement assumptions; real cellular behaviour remains untested.

The external observatory remains a separate synthetic demonstration with 68 cortical parcels. Its 14 deep structures provide anatomy only. It is not an empirical extension of the manuscript.

## What we would measure next

A future SST study would require independently established cell identity and a defined functional outcome under matched stress, such as inhibitory effects on identified target cells, with suitable comparisons and viability measurements. Activity alone would not establish preserved function. This experiment is proposed, not completed.

## What changed and what we verified

The final version adds the StarLens presentation and reported-study explorer to the earlier synthetic workflow. The original editable website source is now pinned at `82d565fd689fd562450327d37c6a83f13692cd38`. All 60 tracked files are included. The source passed 31 JavaScript tests, 16 Python tests and the production build. All 15 built files match the public website byte for byte.

The actual workspace and selected study exports match the source calculations. All 59 study, group and marker export selections preserve their source and missing-value rules. The browser check confirmed the main workflow. The optional external atlas has its own compiled snapshot and synthetic checks; its original editable source is not included.

Biological validation, independent replication and a real functional experiment remain unfinished. These software checks do not establish diagnosis or treatment benefit.

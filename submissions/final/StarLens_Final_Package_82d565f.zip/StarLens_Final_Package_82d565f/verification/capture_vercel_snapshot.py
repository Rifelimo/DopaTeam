"""Preserve the final public Vercel build and its observed local dependencies.

Downloads public files only. Does not change or deploy the website.
Compiled output is not a substitute for the original development repository.
"""
from datetime import datetime, timezone
from hashlib import sha256
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlsplit
from urllib.request import Request, urlopen
import json
import re

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / "website"
ORIGIN = "https://starlens-dopateam.vercel.app"

class Dependencies(HTMLParser):
    def __init__(self):
        super().__init__()
        self.paths = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "script" and attrs.get("src"):
            self.paths.append(attrs["src"])
        if tag == "link" and attrs.get("rel") in ("icon", "stylesheet", "modulepreload"):
            self.paths.append(attrs["href"])
        if tag == "img" and attrs.get("src"):
            self.paths.append(attrs["src"])

if __name__ == "__main__":
    DEST.mkdir(parents=True, exist_ok=True)
    pending = ["/index.html", "/impact.html", "/hackathon.html", "/prototype.html",
               "/brand/LICENSE-FreeSurfer.txt"]
    seen = set()
    files = []
    external = set()
    while pending:
        path = pending.pop(0)
        if path in seen:
            continue
        seen.add(path)
        url = ORIGIN + path
        try:
            with urlopen(Request(url, headers={"User-Agent": "Mozilla/5.0"}), timeout=30) as response:
                data = response.read()
                content_type = response.headers.get("Content-Type", "")
            target = DEST / path.lstrip("/")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            files.append({"url": url, "file": str(target.relative_to(ROOT)), "bytes": len(data),
                          "sha256": sha256(data).hexdigest(), "content_type": content_type})
            refs = []
            if path.endswith(".html"):
                parser = Dependencies()
                parser.feed(data.decode())
                refs = parser.paths
            elif path.endswith((".js", ".css")):
                text = data.decode()
                # Literal relative/absolute asset paths in the actual published code.
                refs = re.findall(r'''["'`]((?:\./|/|brand/|assets/)[^"'`\s<>]+?\.(?:js|css|json|svg|png|webp|jpg|glb|woff2))(?:["'`])''', text)
                refs += re.findall(r'''url\(["']?([^)'"\s]+)["']?\)''', text)
            for ref in refs:
                # fetch("brand/...") is document relative; module imports use ./.
                base = ORIGIN + "/" if ref.startswith(("brand/", "./brand/")) else url
                absolute = urljoin(base, ref)
                if urlsplit(absolute).netloc == urlsplit(ORIGIN).netloc:
                    dependency = urlsplit(absolute).path
                    if dependency not in seen and dependency not in pending:
                        pending.append(dependency)
                elif absolute.startswith("https://"):
                    external.add(absolute)
        except Exception as exc:
            files.append({"url": url, "error": str(exc)})
    report = {"captured_at_utc": datetime.now(timezone.utc).isoformat(), "origin": ORIGIN,
              "kind": "unchanged_public_compiled_build", "files": files,
              "external_dependencies": sorted(external),
              "failure_count": sum("error" in item for item in files),
              "original_source_repository_included": False}
    (ROOT / "website_manifest.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"files": len(files), "failures": report["failure_count"]}))

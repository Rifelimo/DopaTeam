"""Serve the unmodified public build locally; bind to this computer only."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import argparse

PACKAGE = Path(__file__).resolve().parents[1]

class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        route = urlsplit(self.path).path
        if self.directory.endswith("snapshot") and route in ("/", "/observatory", "/observatory/"):
            self.path = "/observatory.html"
        elif route in ("/prototype", "/prototype/"):
            self.path = "/prototype.html"
        return super().do_GET()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=5992)
    parser.add_argument("--site", choices=("website", "atlas"), default="website")
    args = parser.parse_args()
    root = PACKAGE / ("snapshot" if args.site == "atlas" else "website")
    server = ThreadingHTTPServer(("127.0.0.1", args.port), partial(Handler, directory=str(root)))
    print(f"Unchanged public build: http://127.0.0.1:{args.port}/", flush=True)
    server.serve_forever()

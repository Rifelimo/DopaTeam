"""Archive observed public build assets without modifying the deployed website.

This captures compiled files, not the original development repository.
"""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from hashlib import sha256
from html.parser import HTMLParser
from pathlib import Path
import json
import urllib.request
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / "snapshot"
ORIGIN = "https://starlens-brain-atlas.sese16180.chatgpt.site"

class Assets(HTMLParser):
    def __init__(self):
        super().__init__()
        self.urls = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "script" and attrs.get("src"):
            self.urls.append(attrs["src"])
        if tag == "link" and attrs.get("rel") in ("stylesheet", "modulepreload"):
            self.urls.append(attrs["href"])

def capture(item):
    remote, local = item
    request = urllib.request.Request(ORIGIN + remote, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            data = response.read()
            content_type = response.headers.get("Content-Type", "")
        target = DEST / local
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        return {"url": ORIGIN + remote, "file": str(target.relative_to(ROOT)),
                "bytes": len(data), "sha256": sha256(data).hexdigest(), "content_type": content_type}
    except Exception as exc:
        return {"url": ORIGIN + remote, "file": local, "error": str(exc)}

if __name__ == "__main__":
    DEST.mkdir(parents=True, exist_ok=True)
    results = [capture(("/observatory", "observatory.html")),
               capture(("/prototype.html", "prototype.html"))]
    assets = set()
    for item in results:
        if "error" in item:
            continue
        parser = Assets()
        parser.feed((ROOT / item["file"]).read_text())
        for value in parser.urls:
            url = urllib.parse.urljoin(item["url"], value)
            if urllib.parse.urlparse(url).netloc == urllib.parse.urlparse(ORIGIN).netloc:
                assets.add(urllib.parse.urlparse(url).path)
    # Paths observed in the rendered page asset inventory and its provenance text.
    assets.update(("/atlas/lh.json", "/atlas/rh.json", "/atlas/subcortex.json",
                   "/observatory/stage.glb", "/atlas/PROVENANCE.md",
                   "/atlas/SCIENTIFIC_READINESS.md", "/atlas/LICENSE-FreeSurfer.txt",
                   "/atlas/provenance.json", "/atlas/validation.json",
                   "/atlas/subcortex-provenance.json", "/atlas/subcortex-validation.json"))
    with ThreadPoolExecutor(max_workers=4) as pool:
        results.extend(pool.map(capture, [(url, url.lstrip("/")) for url in sorted(assets)]))
    report = {"captured_at_utc": datetime.now(timezone.utc).isoformat(), "origin": ORIGIN,
              "kind": "public_compiled_deployment_snapshot_not_original_source",
              "files": results, "failure_count": sum("error" in item for item in results),
              "limits": ["Source repository and original build configuration are not included.",
                         "A stylesheet may reference externally hosted optional fonts.",
                         "No changes were made to the deployed site."]}
    (ROOT / "snapshot_manifest.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"files": len(results), "failures": report["failure_count"]}))

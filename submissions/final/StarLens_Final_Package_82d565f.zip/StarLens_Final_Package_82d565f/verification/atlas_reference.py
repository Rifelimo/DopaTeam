#!/usr/bin/env python3
"""Independent StarLens synthetic reference checker; NOT Seika original source.
Python 3.10+ standard library only. Default: offline checks and a synthetic report.
Optional: --input PATH --expect-synthetic checks a locally downloaded demo JSON.
No browser, network request, or external transmission is made by this program.
Canonical IDs below were derived from the public cortical assets in ATLAS_SOURCES.
This verifies numerical/data behavior, not browser rendering or atlas geometry.
"""
import argparse
import copy
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import io
import json
import math
from pathlib import Path
import sys
import unittest

CANONICAL_REGIONS = [{'id': 'ctx-lh-bankssts', 'label': 'Banks of superior temporal sulcus'}, {'id': 'ctx-lh-caudalanteriorcingulate', 'label': 'Caudal anterior cingulate'}, {'id': 'ctx-lh-caudalmiddlefrontal', 'label': 'Caudal middle frontal'}, {'id': 'ctx-lh-cuneus', 'label': 'Cuneus'}, {'id': 'ctx-lh-entorhinal', 'label': 'Entorhinal cortex'}, {'id': 'ctx-lh-fusiform', 'label': 'Fusiform gyrus'}, {'id': 'ctx-lh-inferiorparietal', 'label': 'Inferior parietal'}, {'id': 'ctx-lh-inferiortemporal', 'label': 'Inferior temporal'}, {'id': 'ctx-lh-isthmuscingulate', 'label': 'Isthmus cingulate'}, {'id': 'ctx-lh-lateraloccipital', 'label': 'Lateral occipital'}, {'id': 'ctx-lh-lateralorbitofrontal', 'label': 'Lateral orbitofrontal'}, {'id': 'ctx-lh-lingual', 'label': 'Lingual gyrus'}, {'id': 'ctx-lh-medialorbitofrontal', 'label': 'Medial orbitofrontal'}, {'id': 'ctx-lh-middletemporal', 'label': 'Middle temporal'}, {'id': 'ctx-lh-parahippocampal', 'label': 'Parahippocampal gyrus'}, {'id': 'ctx-lh-paracentral', 'label': 'Paracentral lobule'}, {'id': 'ctx-lh-parsopercularis', 'label': 'Pars opercularis'}, {'id': 'ctx-lh-parsorbitalis', 'label': 'Pars orbitalis'}, {'id': 'ctx-lh-parstriangularis', 'label': 'Pars triangularis'}, {'id': 'ctx-lh-pericalcarine', 'label': 'Pericalcarine cortex'}, {'id': 'ctx-lh-postcentral', 'label': 'Postcentral gyrus'}, {'id': 'ctx-lh-posteriorcingulate', 'label': 'Posterior cingulate'}, {'id': 'ctx-lh-precentral', 'label': 'Precentral gyrus'}, {'id': 'ctx-lh-precuneus', 'label': 'Precuneus'}, {'id': 'ctx-lh-rostralanteriorcingulate', 'label': 'Rostral anterior cingulate'}, {'id': 'ctx-lh-rostralmiddlefrontal', 'label': 'Rostral middle frontal'}, {'id': 'ctx-lh-superiorfrontal', 'label': 'Superior frontal'}, {'id': 'ctx-lh-superiorparietal', 'label': 'Superior parietal'}, {'id': 'ctx-lh-superiortemporal', 'label': 'Superior temporal'}, {'id': 'ctx-lh-supramarginal', 'label': 'Supramarginal gyrus'}, {'id': 'ctx-lh-frontalpole', 'label': 'Frontal pole'}, {'id': 'ctx-lh-temporalpole', 'label': 'Temporal pole'}, {'id': 'ctx-lh-transversetemporal', 'label': 'Transverse temporal'}, {'id': 'ctx-lh-insula', 'label': 'Insula'}, {'id': 'ctx-rh-bankssts', 'label': 'Banks of superior temporal sulcus'}, {'id': 'ctx-rh-caudalanteriorcingulate', 'label': 'Caudal anterior cingulate'}, {'id': 'ctx-rh-caudalmiddlefrontal', 'label': 'Caudal middle frontal'}, {'id': 'ctx-rh-cuneus', 'label': 'Cuneus'}, {'id': 'ctx-rh-entorhinal', 'label': 'Entorhinal cortex'}, {'id': 'ctx-rh-fusiform', 'label': 'Fusiform gyrus'}, {'id': 'ctx-rh-inferiorparietal', 'label': 'Inferior parietal'}, {'id': 'ctx-rh-inferiortemporal', 'label': 'Inferior temporal'}, {'id': 'ctx-rh-isthmuscingulate', 'label': 'Isthmus cingulate'}, {'id': 'ctx-rh-lateraloccipital', 'label': 'Lateral occipital'}, {'id': 'ctx-rh-lateralorbitofrontal', 'label': 'Lateral orbitofrontal'}, {'id': 'ctx-rh-lingual', 'label': 'Lingual gyrus'}, {'id': 'ctx-rh-medialorbitofrontal', 'label': 'Medial orbitofrontal'}, {'id': 'ctx-rh-middletemporal', 'label': 'Middle temporal'}, {'id': 'ctx-rh-parahippocampal', 'label': 'Parahippocampal gyrus'}, {'id': 'ctx-rh-paracentral', 'label': 'Paracentral lobule'}, {'id': 'ctx-rh-parsopercularis', 'label': 'Pars opercularis'}, {'id': 'ctx-rh-parsorbitalis', 'label': 'Pars orbitalis'}, {'id': 'ctx-rh-parstriangularis', 'label': 'Pars triangularis'}, {'id': 'ctx-rh-pericalcarine', 'label': 'Pericalcarine cortex'}, {'id': 'ctx-rh-postcentral', 'label': 'Postcentral gyrus'}, {'id': 'ctx-rh-posteriorcingulate', 'label': 'Posterior cingulate'}, {'id': 'ctx-rh-precentral', 'label': 'Precentral gyrus'}, {'id': 'ctx-rh-precuneus', 'label': 'Precuneus'}, {'id': 'ctx-rh-rostralanteriorcingulate', 'label': 'Rostral anterior cingulate'}, {'id': 'ctx-rh-rostralmiddlefrontal', 'label': 'Rostral middle frontal'}, {'id': 'ctx-rh-superiorfrontal', 'label': 'Superior frontal'}, {'id': 'ctx-rh-superiorparietal', 'label': 'Superior parietal'}, {'id': 'ctx-rh-superiortemporal', 'label': 'Superior temporal'}, {'id': 'ctx-rh-supramarginal', 'label': 'Supramarginal gyrus'}, {'id': 'ctx-rh-frontalpole', 'label': 'Frontal pole'}, {'id': 'ctx-rh-temporalpole', 'label': 'Temporal pole'}, {'id': 'ctx-rh-transversetemporal', 'label': 'Transverse temporal'}, {'id': 'ctx-rh-insula', 'label': 'Insula'}]

ATLAS_SOURCES = [{'url': 'https://starlens-brain-atlas.sese16180.chatgpt.site/atlas/lh.json', 'sha256': '7d11f56ee968eb293f3c1b0376281692c56a7e8be8c03613bdd6eb97d4ca64aa', 'verified_region_count': 34, 'retrieved_at_utc': '2026-09-15T00:27:32.819235+00:00'}, {'url': 'https://starlens-brain-atlas.sese16180.chatgpt.site/atlas/rh.json', 'sha256': '7368f76c41f0b5bc305051c23e1f8b50bcc93601ddcd4de185e04d4a7b01926b', 'verified_region_count': 34, 'retrieved_at_utc': '2026-09-15T00:27:33.035598+00:00'}]

PUBLISHED_CHUNK_SHA256 = "d2e9feed0c142ac530b25892b53fb8f6eda4471d8da2fbc02e955babc0240417"


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def ranks(values):
    if not all(finite(value) for value in values):
        raise ValueError('Ranks require finite numbers.')
    ordered = sorted(range(len(values)), key=values.__getitem__)
    result = [0.0] * len(values)
    start = 0
    while start < len(values):
        end = start + 1
        while end < len(values) and values[ordered[end]] == values[ordered[start]]:
            end += 1
        for index in ordered[start:end]:
            result[index] = (start + end + 1) / 2
        start = end
    return result


def paired_spearman(first, second):
    if len(first) != len(second):
        raise ValueError('Vectors must be aligned and have equal length.')
    pairs = [(x, y) for x, y in zip(first, second) if finite(x) and finite(y)]
    count = len(pairs)
    if count < 3:
        return {'n': count, 'rho': None}
    x = ranks([pair[0] for pair in pairs])
    y = ranks([pair[1] for pair in pairs])
    mx, my = sum(x) / count, sum(y) / count
    xx = sum((value - mx) ** 2 for value in x)
    yy = sum((value - my) ** 2 for value in y)
    if xx == 0 or yy == 0:
        return {'n': count, 'rho': None}
    xy = sum((a - mx) * (b - my) for a, b in zip(x, y))
    return {'n': count, 'rho': max(-1.0, min(1.0, xy / math.sqrt(xx * yy)))}


def normalize_bundle(bundle):
    if bundle.get('schema') != 'starlens-atlas-v1' or bundle.get('atlas') != 'fsaverage5-dk68':
        raise ValueError('Expected starlens-atlas-v1 and fsaverage5-dk68.')
    if bundle.get('kind') not in ('synthetic', 'research-aggregate'):
        raise ValueError('Unknown data kind.')
    canonical = [region['id'] for region in CANONICAL_REGIONS]
    supplied = [region.get('id') for region in bundle.get('regions', [])]
    if len(supplied) != 68 or any(type(x) is not str for x in supplied) or len(set(supplied)) != 68 or set(supplied) != set(canonical):
        raise ValueError('Expected exactly the 68 unique verified anatomical IDs.')
    source = bundle.get('source')
    if not isinstance(source, dict) or not isinstance(source.get('title'), str) or not source['title'].strip():
        raise ValueError('A source title is required.')
    positions = {identifier: i for i, identifier in enumerate(supplied)}
    result = copy.deepcopy(bundle)
    result['regions'] = copy.deepcopy(CANONICAL_REGIONS)
    for field, limit in [('profiles', 20), ('maps', 100)]:
        layers = result.get(field)
        if not isinstance(layers, list) or not 1 <= len(layers) <= limit:
            raise ValueError('Invalid layer count.')
        ids = []
        for layer in layers:
            if not isinstance(layer, dict) or not isinstance(layer.get('id'), str) or not layer['id']:
                raise ValueError('Layer ID required.')
            ids.append(layer['id'])
            if not isinstance(layer.get('label') or layer.get('name'), str):
                raise ValueError('Layer label or name required.')
            for key in ['label', 'name', 'unit']:
                if key in layer and not isinstance(layer[key], str):
                    raise ValueError('Layer text metadata must be text.')
            values = layer.get('values')
            if not isinstance(values, list) or len(values) != 68 or any(value is not None and not finite(value) for value in values):
                raise ValueError('Each layer needs 68 finite numbers or nulls.')
            layer['values'] = [values[positions[identifier]] for identifier in canonical]
        if len(set(ids)) != len(ids):
            raise ValueError('Repeated layer ID.')
    return result


def four_places(value):
    # Decimal.from_float starts from the actual binary double; midpoint rounding
    # is away from zero, as for Number(...toFixed(4)). No third-party JS executes.
    return float(Decimal.from_float(value).quantize(Decimal('0.0001'), rounding=ROUND_HALF_UP))


def synthetic_bundle():
    profile = [four_places(math.sin(i * 1.71) * .75 + math.cos(i * .43) * .25) for i in range(68)]
    reference = [four_places(math.cos(i * 1.13) * .6 + math.sin(i * .43) * .4) for i in range(68)]
    return {
        'schema': 'starlens-atlas-v1', 'atlas': 'fsaverage5-dk68', 'kind': 'synthetic',
        'source': {'title': 'Procedural demo values, not study findings', 'license': 'Demo generated in the browser'},
        'regions': copy.deepcopy(CANONICAL_REGIONS),
        'profiles': [{'id': 'regional-profile', 'label': 'Synthetic regional profile', 'unit': 'Arbitrary units', 'values': profile}],
        'maps': [{'id': 'reference-pattern', 'name': 'Synthetic reference pattern', 'unit': 'Arbitrary units', 'values': reference}],
    }


class ReferenceChecks(unittest.TestCase):
    def test_average_tied_ranks(self):
        self.assertEqual(ranks([4, 1, 1, 8]), [3, 1.5, 1.5, 4])

    def test_tied_monotonic(self):
        self.assertEqual(paired_spearman([1, 1, 3, 4], [2, 2, 6, 8]), {'n': 4, 'rho': 1.0})

    def test_reverse_monotonic(self):
        self.assertEqual(paired_spearman([1, 2, 3], [3, 2, 1])['rho'], -1.0)

    def test_pairwise_nulls(self):
        self.assertEqual(paired_spearman([1, None, 3, 4, 5], [9, 8, None, 6, 5]), {'n': 3, 'rho': -1.0})

    def test_insufficient_pairs(self):
        self.assertEqual(paired_spearman([1, None, 3], [4, 5, 6]), {'n': 2, 'rho': None})

    def test_constant(self):
        self.assertIsNone(paired_spearman([1, 1, 1], [1, 2, 3])['rho'])

    def test_misaligned_length(self):
        with self.assertRaises(ValueError):
            paired_spearman([1, 2, 3], [1, 2])

    def test_permuted_ids(self):
        expected = synthetic_bundle()
        changed = copy.deepcopy(expected)
        changed['regions'].reverse()
        for field in ['profiles', 'maps']:
            for layer in changed[field]:
                layer['values'].reverse()
        self.assertEqual(normalize_bundle(changed), expected)

    def test_duplicate_ids(self):
        bundle = synthetic_bundle()
        bundle['regions'][1]['id'] = bundle['regions'][0]['id']
        with self.assertRaises(ValueError):
            normalize_bundle(bundle)

    def test_unknown_ids(self):
        bundle = synthetic_bundle()
        bundle['regions'][0]['id'] = 'r01'
        with self.assertRaises(ValueError):
            normalize_bundle(bundle)

    def test_boolean_is_not_number(self):
        bundle = synthetic_bundle()
        bundle['profiles'][0]['values'][0] = True
        with self.assertRaises(ValueError):
            normalize_bundle(bundle)

    def test_null_preservation(self):
        bundle = synthetic_bundle()
        bundle['maps'][0]['values'][3] = None
        self.assertIsNone(normalize_bundle(bundle)['maps'][0]['values'][3])

    def test_expected_synthetic_rho(self):
        bundle = synthetic_bundle()
        value = paired_spearman(bundle['profiles'][0]['values'], bundle['maps'][0]['values'])
        self.assertEqual(value['n'], 68)
        self.assertAlmostEqual(value['rho'], 0.028476543115623927, places=14)
        self.assertEqual(format(value['rho'], '.3f'), '0.028')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='Optional local atlas data JSON to validate and compare.')
    parser.add_argument('--expect-synthetic', action='store_true', help='Require the input to match this independently generated demo exactly after ID normalization.')
    parser.add_argument('--output', type=Path, default=Path(__file__).with_name('atlas_reference_output.json'))
    parser.add_argument('--log', type=Path, default=Path(__file__).with_name('atlas_reference_tests.log'))
    args = parser.parse_args()
    if args.expect_synthetic and args.input is None:
        parser.error('--expect-synthetic requires --input.')
    capture = io.StringIO()
    tests = unittest.TextTestRunner(stream=capture, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ReferenceChecks))
    args.log.parent.mkdir(parents=True, exist_ok=True)
    args.log.write_text(capture.getvalue(), encoding='utf-8')
    fixture = synthetic_bundle()
    report = {
        'status': 'passed' if tests.wasSuccessful() else 'failed',
        'implementation': 'Original independent Python reference checker; not Seika original application source.',
        'checked_at_utc': datetime.now(timezone.utc).isoformat(),
        'provenance_scope': 'The final starlens-dopateam.vercel.app site links to this separate external ChatGPT.site atlas. This checker verifies that external 68-region component and its captured export, not the Vercel narrative or 82-region model workspace.',
        'public_chunk_sha256': PUBLISHED_CHUNK_SHA256,
        'atlas_sources': ATLAS_SOURCES,
        'reference_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'python_version': sys.version,
        'test_counts': {'run': tests.testsRun, 'failures': len(tests.failures), 'errors': len(tests.errors), 'skipped': len(tests.skipped)},
        'synthetic_formulas': {'profile': 'round4(sin(i*1.71)*0.75 + cos(i*0.43)*0.25)', 'reference': 'round4(cos(i*1.13)*0.6 + sin(i*0.43)*0.4)', 'index': 'i=0..67 in verified left-then-right cortical asset order'},
        'synthetic_fixture': fixture,
        'synthetic_comparison': paired_spearman(fixture['profiles'][0]['values'], fixture['maps'][0]['values']),
        'expected_ui_display': '0.028',
        'browser_export_comparison': None,
        'limitations': ['No browser, rendering, camera, mesh geometry or original application test suite is executed.', 'Reference tests are 13 new checks of this independent implementation, not the 42 DopaTeam tests.', 'The atlas JSON export does not encode selected profile/reference or display state; the demo has one of each.'],
    }
    try:
        if args.input:
            raw = args.input.read_bytes()
            actual = normalize_bundle(json.loads(raw))
            matches = actual == fixture
            if args.expect_synthetic and not matches:
                raise ValueError('Browser input does not exactly match the independently generated synthetic fixture.')
            report['browser_export_comparison'] = {
                'input_name': args.input.name, 'input_sha256': hashlib.sha256(raw).hexdigest(),
                'canonical_ids_match': True, 'exact_normalized_fixture_match': matches,
                'first_profile_id': actual['profiles'][0]['id'], 'first_reference_id': actual['maps'][0]['id'],
                'first_pair_comparison': paired_spearman(actual['profiles'][0]['values'], actual['maps'][0]['values']),
            }
    except Exception as error:
        report['status'] = 'failed'
        report['error'] = str(error)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'tests': report['test_counts'], 'synthetic_comparison': report['synthetic_comparison'], 'browser_export_comparison': report['browser_export_comparison'], 'output': str(args.output)}, indent=2))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())

#!/usr/bin/env node
// Verify the final editable source and captured browser exports offline.
// Default is read-only. --record replaces this checker's JSON and text evidence.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync,readdirSync,lstatSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {join,relative} from 'node:path';

const root=new URL('../',import.meta.url);
const source=new URL('source/',root);
const expectedCommit='82d565fd689fd562450327d37c6a83f13692cd38';
const tolerance=1e-12;
const read=path=>JSON.parse(readFileSync(new URL(path,root),'utf8'));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const fileSha=url=>sha(readFileSync(url));
const log=[];
const report={status:'running',checkedAt:new Date().toISOString(),scope:'Final editable main-site source and captured outputs; the external atlas is separate.',numericAbsoluteTolerance:tolerance,checks:[]};

function equal(actual,expected,path='value'){
 if(typeof expected==='number'){
  assert.equal(typeof actual,'number',`${path}: numeric type`);
  assert.ok(Number.isFinite(actual)&&Number.isFinite(expected)&&Math.abs(actual-expected)<=tolerance,`${path}: numeric mismatch`);
 }else if(Array.isArray(expected)){
  assert.ok(Array.isArray(actual),`${path}: expected array`);
  assert.equal(actual.length,expected.length,`${path}: array length`);
  expected.forEach((value,index)=>equal(actual[index],value,`${path}[${index}]`));
 }else if(expected!==null&&typeof expected==='object'){
  assert.ok(actual!==null&&typeof actual==='object'&&!Array.isArray(actual),`${path}: expected object`);
  assert.deepEqual(Object.keys(actual).sort(),Object.keys(expected).sort(),`${path}: object keys`);
  for(const key of Object.keys(expected))equal(actual[key],expected[key],`${path}.${key}`);
 }else assert.equal(actual,expected,`${path}: value mismatch`);
}
function check(name,actual,expected){equal(actual,expected,name);report.checks.push(name);log.push(`PASS ${name}`);}
function filesUnder(directory){
 const files=[];
 for(const name of readdirSync(directory)){
  if(name==='.DS_Store')continue;
  const path=join(directory,name),stat=lstatSync(path);
  assert.ok(!stat.isSymbolicLink(),`Source symlink is not allowed: ${path}`);
  if(stat.isDirectory())files.push(...filesUnder(path));
  else if(stat.isFile())files.push(path);
 }
 return files;
}

try{
 assert.ok(process.argv.slice(2).every(arg=>arg==='--record'),'Only --record is supported.');
 const pin=read('SOURCE_PIN.json');
 assert.equal(pin.commit,expectedCommit);
 assert.equal(pin.source_file_count,60);
 assert.equal(pin.source_files.length,60);
 const names=pin.source_files.map(row=>row.path);
 assert.equal(new Set(names).size,60);
 assert.ok(names.every(name=>typeof name==='string'&&!name.startsWith('/')&&!name.split('/').includes('..')),'Safe source-relative paths required.');
 const actualNames=filesUnder(fileURLToPath(source)).map(path=>relative(fileURLToPath(source),path).split('\\').join('/')).sort();
 check('Exact 60-file final source inventory',actualNames,[...names].sort());
 for(const row of pin.source_files)assert.equal(fileSha(new URL(row.path,source)),row.sha256,`Source SHA256: ${row.path}`);
 check('All final source file hashes match the pinned commit record',true,true);
 report.source={commit:pin.commit,sourceFileCount:pin.source_file_count,pinSha256:fileSha(new URL('SOURCE_PIN.json',root))};
 const {syntheticBundle}=await import(new URL('src/data/synthetic.mjs',source));
 const {validateBundle,rankMaps,looRange,defaults,evaluate}=await import(new URL('src/core/model.mjs',source));
 const {studies,findRecord,evidenceExport}=await import(new URL('src/data/studies.mjs',source));
 const generated=validateBundle(syntheticBundle);
 const serialized=validateBundle(read('core_reproducibility/inputs/synthetic_input.json'));
 check('Serialized synthetic input matches final source generator',serialized,generated);
 check('Synthetic dimensions',[generated.regions.length,generated.profiles.length,generated.maps.length],[82,1,30]);
 const workspace=read('outputs/vercel_workspace_export.json');
 const selectedProfile=generated.profiles.find(item=>item.id===workspace.profile.id);
 assert.ok(selectedProfile,'Workspace profile must exist in pinned synthetic input.');
 const ranking=rankMaps(selectedProfile.values,generated.maps);
 const associations=ranking.map(({id,name,rho})=>({id,name,rho}));
 check('Actual workspace synthetic identity and provenance',{project:workspace.project,version:workspace.version,dataKind:workspace.dataKind,source:workspace.source,profile:workspace.profile},{project:'DopaTeam',version:read('source/package.json').version,dataKind:generated.kind,source:generated.source,profile:{id:selectedProfile.id,label:selectedProfile.label}});
 check('All 30 actual workspace associations match final source',workspace.associations,associations);
 check('Actual workspace parameters match final defaults',workspace.parameters,defaults);
 check('Actual workspace results match final evaluation',workspace.result,evaluate(defaults));
 check('Workspace exported data excludes raw regional arrays',[workspace.rawImportedArraysIncluded,workspace.associations.some(item=>'values' in item)],[false,false]);
 assert.ok(typeof workspace.exportedAt==='string'&&/^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:\d{2})$/.test(workspace.exportedAt)&&Number.isFinite(Date.parse(workspace.exportedAt)),'Valid workspace export timestamp required.');
 check('Actual workspace timestamp is valid',true,true);
 const topFive=ranking.slice(0,5).map(map=>({id:map.id,name:map.name,rho:map.rho,leaveOneOut:looRange(selectedProfile.values,map.values)}));
 check('Final source top-five sensitivity matches archived CLI',topFive,read('core_reproducibility/outputs/comparison.json').topMaps);
 const captured=read('outputs/reported_study_export.json');
 const {studyId,groupId,markerId}=captured.selection;
 // Compare the serialized export, preserving sourceDisplay while allowing JSON's
 // standard conversion of numeric negative zero to zero.
 assert.deepEqual(captured,JSON.parse(JSON.stringify(evidenceExport(studyId,groupId,markerId))));
 check('Actual selected reported-study export matches final source exactly',true,true);
 const selections=[];
 let missing=0,reported=0;
 for(const study of studies)for(const group of study.groups)for(const marker of study.markers){
  const result=evidenceExport(study.id,group.id,marker.id);
  assert.equal(result.schemaVersion,1);
  assert.equal(result.project,'StarLens');
  assert.equal(result.dataKind,'reported-study-aggregates');
  assert.deepEqual(result.selection,{studyId:study.id,groupId:group.id,markerId:marker.id});
  assert.equal(result.source.title,study.title);
  assert.equal(result.source.status,study.status);
  assert.deepEqual([result.rawPatientDataIncluded,result.reanalysisPerformed,result.clinicalInference],[false,false,false]);
  assert.equal(result.groupResults.length,study.markers.length);
  assert.equal(result.regionalEffectSizes.length,study.atrophy.length);
  const selected=findRecord(study.id,group.id,marker.id);
  assert.deepEqual(result.selectedResult,selected);
  assert.deepEqual(result.groupResults.find(item=>item.markerId===marker.id),selected);
  for(const record of result.groupResults){
   assert.equal(record.groupId,group.id);
   assert.ok(record.rho===null||(Number.isFinite(record.rho)&&Math.abs(record.rho)<=1));
   for(const key of ['p','q'])assert.ok(record[key]===null||(Number.isFinite(record[key])&&record[key]>=0&&record[key]<=1));
   assert.ok(record.fdrReported===null||typeof record.fdrReported==='boolean');
   assert.ok(record.source&&Number.isInteger(record.source.pdfPage)&&record.source.pdfPage>0&&typeof record.source.location==='string');
   if(record.rho===null){
    assert.deepEqual([record.p,record.q,record.fdrReported],[null,null,null]);
    assert.ok(typeof record.missingReason==='string'&&record.missingReason.length>0);
   }
  }
  result.regionalEffectSizes.forEach((row,index)=>{
   const displayed=study.atrophy[index].values[group.id];
   assert.equal(row.sourceDisplay,displayed);
   assert.ok(Object.is(row.cohensD,displayed===null?null:Number(displayed)),'Retain negative-zero numeric conversion and original sourceDisplay.');
   assert.deepEqual(row.source,study.atrophy[index].source);
  });
  const encoded=JSON.stringify(result);
  assert.doesNotMatch(encoded,/Users[\\/]|sourcePdfLocalPath/);
  if(selected.rho===null)missing++;else reported++;
  selections.push({studyId:study.id,groupId:group.id,markerId:marker.id,rho:selected.rho,missing:selected.rho===null,exportSha256:sha(encoded)});
 }
 check('All selectable reported-evidence combinations checked',selections.length,59);
 check('Reported and explicitly missing selected coefficients',[reported,missing],[55,4]);
 check('Reported export provenance, null conventions and disclosure flags',true,true);
 report.evidenceSelections={checked:selections.length,reported,missing,selections};
 report.workspace={path:'outputs/vercel_workspace_export.json',sha256:fileSha(new URL('outputs/vercel_workspace_export.json',root)),associations,parameters:defaults,result:evaluate(defaults),topFiveWithLeaveOneOut:topFive};
 report.reportedStudy={path:'outputs/reported_study_export.json',sha256:fileSha(new URL('outputs/reported_study_export.json',root)),selection:captured.selection};
 report.limits=['These are source/export consistency checks, not a fresh run of the repository Node/Python suites or build.','The 59 evidence combinations are software selections, not 59 new empirical analyses or independent tests.','Source transcription against the papers, browser rendering and the separate external atlas require their own evidence.','Leave-one-out ranges are compared with archived CLI output; the workspace JSON does not contain them.'];
 report.status='passed';
}catch(error){report.status='failed';report.error=error.message;log.push(`FAIL ${error.stack||error.message}`);}
report.finishedAt=new Date().toISOString();
report.checkerSha256=fileSha(new URL(import.meta.url));
if(process.argv.includes('--record')){
 writeFileSync(new URL('verification/final_source_verification.json',root),JSON.stringify(report,null,2)+'\n');
 writeFileSync(new URL('verification/final_source_verification.log',root),log.join('\n')+'\n');
}
console.log(JSON.stringify({status:report.status,sourceCommit:report.source?.commit,checks:report.checks.length,evidenceSelections:report.evidenceSelections?.checked,recorded:process.argv.includes('--record'),error:report.error},null,2));
process.exitCode=report.status==='passed'?0:1;

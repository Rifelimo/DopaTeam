#!/usr/bin/env node
// Offline numerical verification of the captured Vercel workspace export.
// This is package verification code, not the original Vercel application source.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';

const root=new URL('../',import.meta.url);
const core=new URL('core_reproducibility/',root);
const tolerance=1e-12;
const read=path=>JSON.parse(readFileSync(new URL(path,root),'utf8'));
const sha=url=>createHash('sha256').update(readFileSync(url)).digest('hex');
const log=[];
const report={status:'running',checkedAt:new Date().toISOString(),implementation:'Offline checker using the pinned original DopaTeam core; not a reconstruction of the Vercel application.',numericAbsoluteTolerance:tolerance,checks:[]};
function equal(actual,expected,path='value'){
 if(typeof expected==='number'){
  assert.equal(typeof actual,'number',`${path}: numeric type`);
  assert.ok(Number.isFinite(actual)&&Number.isFinite(expected)&&Math.abs(actual-expected)<=tolerance,`${path}: numeric mismatch`);
 }else if(Array.isArray(expected)){
  assert.ok(Array.isArray(actual),`${path}: expected array`);
  assert.equal(actual.length,expected.length,`${path}: array length`);
  expected.forEach((value,index)=>equal(actual[index],value,`${path}[${index}]`));
 }else if(expected!==null&&typeof expected==='object'){
  assert.ok(actual!==null&&typeof actual==='object'&&!Array.isArray(actual),`${path}: expected object`);
  assert.deepEqual(Object.keys(actual).sort(),Object.keys(expected).sort(),`${path}: object keys`);
  for(const key of Object.keys(expected))equal(actual[key],expected[key],`${path}.${key}`);
 }else assert.equal(actual,expected,`${path}: value mismatch`);
}
function check(name,actual,expected){equal(actual,expected,name);report.checks.push(name);log.push(`PASS ${name}`);}
try{
 const pin=read('core_reproducibility/PINNED_VERSION.json');
 assert.equal(pin.commit,'34c4d158ff1ba4be7611ea2d6a35b1c6f3bb394f');
 assert.equal(pin.code_file_count,44);
 assert.equal(pin.code_files.length,44);
 assert.equal(new Set(pin.code_files.map(row=>row.path)).size,44);
 for(const row of pin.code_files)assert.equal(sha(new URL(`code/${row.path}`,core)),row.sha256,`Pinned source hash: ${row.path}`);
 check('All 44 listed pinned source files match their recorded SHA256',true,true);
 report.pinnedCore={commit:pin.commit,version:pin.version,filesVerified:44};
 const {syntheticBundle}=await import(new URL('code/src/data/synthetic.mjs',core));
 const {validateBundle,rankMaps,looRange,defaults,evaluate}=await import(new URL('code/src/core/model.mjs',core));
 const generated=validateBundle(syntheticBundle);
 const serialized=validateBundle(read('core_reproducibility/inputs/synthetic_input.json'));
 check('Serialized 82-region input matches pinned synthetic generator',serialized,generated);
 check('Synthetic input dimensions',[generated.regions.length,generated.profiles.length,generated.maps.length],[82,1,30]);
 const captured=read('outputs/vercel_workspace_export.json');
 const previous=read('core_reproducibility/outputs/interface_export.json');
 const comparison=read('core_reproducibility/outputs/comparison.json');
 const profile=generated.profiles[0];
 const ranking=rankMaps(profile.values,generated.maps);
 const associations=ranking.map(({id,name,rho})=>({id,name,rho}));
 const topFive=ranking.slice(0,5).map(map=>({id:map.id,name:map.name,rho:map.rho,leaveOneOut:looRange(profile.values,map.values)}));
 check('Workspace project and version',[captured.project,captured.version],['DopaTeam',pin.version]);
 check('Workspace data kind remains synthetic',captured.dataKind,generated.kind);
 check('Workspace source provenance matches pinned input',captured.source,generated.source);
 check('Workspace selected profile matches pinned default',captured.profile,{id:profile.id,label:profile.label});
 check('All 30 captured workspace associations match pinned calculations',captured.associations,associations);
 check('Workspace default parameters match pinned defaults',captured.parameters,defaults);
 check('Workspace model result matches pinned evaluation',captured.result,evaluate(defaults));
 check('Workspace does not include raw regional arrays',[captured.rawImportedArraysIncluded,captured.associations.some(map=>'values' in map)],[false,false]);
 assert.equal(typeof captured.exportedAt,'string');
 assert.ok(/^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:\d{2})$/.test(captured.exportedAt)&&Number.isFinite(Date.parse(captured.exportedAt)),'Valid export timestamp with timezone');
 check('Workspace export has a valid timestamp',true,true);
 const {exportedAt:oldTime,...oldContent}=previous;
 const {exportedAt:newTime,...newContent}=captured;
 check('Full captured content matches earlier pinned export except timestamp',newContent,oldContent);
 check('Recomputed top-five leave-one-out ranges match archived CLI',topFive,comparison.topMaps);
 const historical=read('core_reproducibility/verification/run/summary.json');
 check('Historical core verification commit',historical.commit,pin.commit);
 check('Historical core verification records success',[historical.status,historical.build,historical.test_counts.javascript,historical.test_counts.python,historical.test_counts.total],['passed','passed',26,16,42]);
 report.historicalCoreTests={rerunHere:false,source:'core_reproducibility/verification/run/summary.json',recordedAt:historical.finished_at_utc,recordedPassed:42};
 report.workspaceExport={path:'outputs/vercel_workspace_export.json',sha256:sha(new URL('outputs/vercel_workspace_export.json',root)),exportedAt:captured.exportedAt};
 report.computed={associations,topFiveWithLeaveOneOut:topFive,parameters:defaults,result:evaluate(defaults)};
 report.scope=['The 30 associations and default model are compared against the actual captured Vercel export.','Leave-one-out ranges are compared with archived CLI results; the workspace JSON does not export these ranges.','The original 42 tests were not rerun; their saved results and pinned source file hashes are checked.','Reported-study aggregates, manuscript claims, browser rendering and external 68-region atlas are separate evidence and are not validated here.'];
 report.status='passed';
}catch(error){report.status='failed';report.error=error.message;log.push(`FAIL ${error.stack||error.message}`);}
report.finishedAt=new Date().toISOString();
report.checkerSha256=sha(new URL(import.meta.url));
if(process.argv.includes('--record')){
 writeFileSync(new URL('verification/workspace_verification.json',root),JSON.stringify(report,null,2)+'\n');
 writeFileSync(new URL('verification/workspace_verification.log',root),log.join('\n')+'\n');
}
console.log(JSON.stringify({status:report.status,checks:report.checks.length,recorded:process.argv.includes('--record'),error:report.error},null,2));
process.exitCode=report.status==='passed'?0:1;

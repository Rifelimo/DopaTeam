"""Verify the preserved package and numerical results without changing its files."""
from pathlib import Path
from hashlib import sha256
import json
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]

def run(argv):
    result = subprocess.run(argv, cwd=ROOT, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    return result

if __name__ == "__main__":
    manifest = json.loads((ROOT / "PACKAGE_MANIFEST.json").read_text())
    for item in manifest["files"]:
        path = ROOT / item["path"]
        if not path.is_file() or sha256(path.read_bytes()).hexdigest() != item["sha256"]:
            raise RuntimeError(f"Missing or changed file: {item['path']}")
    print(f"Package files verified: {len(manifest['files'])}")
    with tempfile.TemporaryDirectory(prefix="starlens-check-") as tmp:
        output = Path(tmp)
        run([sys.executable, "verification/atlas_reference.py", "--input",
             "inputs/atlas_browser_export.json", "--expect-synthetic",
             "--output", str(output / "atlas.json"), "--log", str(output / "atlas.log")])
        atlas = json.loads((output / "atlas.json").read_text())
        assert atlas["status"] == "passed"
        print("Independent cortical reference: 13 tests passed; actual browser export matched.")
        # Both source checkers are read-only unless --record is explicitly requested.
        print("Final editable main-site source: pinned hashes, synthetic workspace, and reported-evidence exports.")
        result = run(["node", "verification/verify_final_source.mjs"])
        print(result.stdout.strip())
        print("Historical core scope: original 34c4d158 source and saved 42-test record; no historical tests rerun here.")
        result = run(["node", "verification/verify_workspace.mjs"])
        print(result.stdout.strip())
    # A verification run must leave the captured package unchanged.
    for item in manifest["files"]:
        assert sha256((ROOT / item["path"]).read_bytes()).hexdigest() == item["sha256"], item["path"]
    print("Package remained unchanged. Biological efficacy is not tested.")

# StarLens by DopaTeam

Life Sciences · Code parcel 04 of 04 · Complete local prototype

[GitHub](https://github.com/Rifelimo/DopaTeam) · [Project presentation](https://dopateam.vercel.app) · [Release history](CHANGELOG.md)

DopaTeam explores how regional brain patterns can inform a next research question. We start with a descriptive comparison, show why that comparison alone does not determine function in an explicit model, then make the same workflow usable with aligned local inputs and an interactive view.

The first view presents reported aggregates from a 2025 publication and a separate 2026 submitted manuscript. The regional sandbox uses invented values. These views support inspection of evidence and assumptions; neither identifies an effective medicine or reruns the original cohort analyses.

## Results at a glance

- The regional comparison runs on 82 synthetic regions and 30 synthetic reference maps. The strongest example association is 0.818. Loading the same example from a local file gives the same result.
- With identical observed inputs, the model produces functional outputs of 1.008 and 0.576 when the assumed response gains differ. Setting the gains equal removes the difference.
- The local interface brings the comparison, model, input validation and export together. The exported report includes the parameters and results, without the raw imported value arrays.
- Current verification passed 31 Node tests, 16 Python tests, browser checks and the four-page production build. Reported values were independently compared with the supplied PDFs.

These are reproducible software and simulation results. The model parameters were not fitted to patients, and no treatment benefit was tested.

## Run the current release

Node.js 22.12 or later and Python 3.10 or later. The command line calculations use built in libraries.

```sh
npm run demo
npm run states
npm run reference
npm run compare
```

What to look for:

- **Map comparison:** 82 invented regions, 30 invented maps and five leading associations. The first map is `reference-17`, with signed correlation about `0.818308`. The sensitivity range is not a confidence interval.
- **State comparison:** the same structural inputs accompany model outputs `1.008` and `0.576`. This happens because the model contains an unobserved response gain. It illustrates a limitation of the stated observation model.
- **Independent reference:** Python reproduces the default state outputs and the `4.32` difference divided by assumed noise. Its regional fixture is separate; do not compare its map rankings with the JavaScript fixture. Model time is arbitrary, not years.

Read [THEORY.md](THEORY.md) for the equations, assumptions and what this example can establish.

## Compare your own aligned inputs

```sh
npm run compare -- --input /path/to/bundle.json --profile AD_vs_CN
```

Use an authorized local bundle with the specified profile. The command checks the input before calculating results. It prints only a local comparison and never uploads the file. The [local import guide](docs/local-import.md) covers the audited CSV converter, required alignment and source revision. Standard tests need no research access.

## Run the interactive prototype

[Open the public prototype](https://dopateam.vercel.app/prototype.html). The presentation remains at the main website address.

```sh
npm ci
npm run dev
```

Open http://127.0.0.1:5184/prototype.html. Study evidence compares reported results from the two papers. Regional sandbox, Competing states and Next experiment retain the original functions and input validator. Reported paper values do not set the hypothetical gain, noise or transition-time parameters.

```sh
npm run build
npm run preview
```

The build writes all four pages and their assets to `prototype-dist/`. Preview serves the redesigned overview at `/`, scientific context at `/impact.html`, build evidence at `/hackathon.html`, and the analysis workspace at `/prototype.html`.

## Website and visual design

The StarLens website uses a black canvas, regular Noto Sans JP typography, violet actions and an original particle illustration derived from licensed standard brain geometry. Its homepage now embeds the same study-evidence explorer as the workspace. It displays 39 published group mean correlations, 16 selected manuscript correlations and explicit missing values. The full workspace also shows 44 rounded regional effect-size values from Figure 2A.

Read [reported-data provenance and limits](docs/STUDY_EVIDENCE.md) before reusing any result. The 2026 source is a submitted manuscript, not an established accepted publication. The PDF files, individual records and complete regional arrays are not distributed here.

The separately published [Neural Observatory](https://starlens-brain-atlas.sese16180.chatgpt.site/observatory.html) is linked from the overview. It is not bundled here. Standard anatomy and illustrative overlays do not establish a correspondence with the prototype's invented region IDs.

Read [website maintenance and verification](docs/WEBSITE_REDESIGN.md) and [brain illustration provenance](docs/BRAND_VISUAL_PROVENANCE.md). The numerical model, original fixtures and validation rules are unchanged by the redesign.

## Verify the release

```sh
npm test
npm run test:python
```

Checks cover known rank examples, unchanged descriptors under alternate model gains, threshold substitution, controls with equal gains, invalid inputs and agreement between JavaScript and Python. Later releases retain these checks and add tests for their own input and interface paths. Software checks do not establish biological validity.

## How the code grows

| Parcel | Capability | Status in this release |
| --- | --- | --- |
| 01 | Rank regional patterns and inspect sensitivity | Available |
| 02 | Test the limits of interpreting a fixed pattern | Available |
| 03 | Validate and compare local input bundles | Available |
| 04 | Explore the same functions in one interface | Available |

**Next:** perform the final source and reproducibility check before tagging `checkpoint-final`.

[ROADMAP.md](ROADMAP.md) explains why each step follows the previous one, its acceptance criteria and publication time. Each version is cumulative. Existing implementation is published gradually with its origin recorded; publication dates do not imply new experiments or new dates for earlier research.

## Team and scientific basis

Ricardo Félix Morais leads DopaTeam with Alex Chen and Seika Karamatsu. Ricardo is a neuroradiologist, researcher and MIT Sloan Fellows MBA student. Codex assisted with code, documentation and review.

The scientific background includes Ricardo's [2025 Neurobiology of Disease paper](https://pubmed.ncbi.nlm.nih.gov/40194635/) and the separate 2026 manuscript on neurochemical and cellular vulnerability by João Valério Rocha, João Paulo Silva Cunha and Ricardo Félix Morais. These studies motivate the question; they do not validate the illustrative model. [PROVENANCE.md](PROVENANCE.md) identifies the prior research and the source of this implementation.

The package includes transcribed aggregate results but no original MINNT notebook, participant records or complete regional input arrays. Checkpoint folder submission and video are handled separately.

## Methods and verified results

Read [the detailed technical report](docs/METHODS_AND_RESULTS.md) for the calculations, numerical results, input checks, interface behaviour and validation of this final code package.
